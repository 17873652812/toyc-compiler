#pragma once

#include "defs.h"
#include <memory>
#include <vector>

namespace toyc {

// ASTNode：所有语法树节点的基类
struct ASTNode {
    virtual ~ASTNode() = default;
};

// ---- 表达式 ----

// 数字：42, 0, 100
struct NumberExpr : ASTNode {
    int value;
    explicit NumberExpr(int v) : value(v) {}
};

// 变量引用：x, y, main
struct IdExpr : ASTNode {
    std::string name;
    explicit IdExpr(std::string n) : name(std::move(n)) {}
};

// 二元运算：a + b, x * 2, y - 1
struct BinaryExpr : ASTNode {
    std::unique_ptr<ASTNode> left;
    std::string op;   // "+" "-" "*" "/" "%"
    std::unique_ptr<ASTNode> right;
    BinaryExpr(std::unique_ptr<ASTNode> l, std::string o,
               std::unique_ptr<ASTNode> r)
        : left(std::move(l)), op(std::move(o)), right(std::move(r)) {}
};

// 一元运算：-a, !x, +3
struct UnaryExpr : ASTNode {
    std::string op;   // "-" "!" "+"
    std::unique_ptr<ASTNode> expr;
    UnaryExpr(std::string o, std::unique_ptr<ASTNode> e)
        : op(std::move(o)), expr(std::move(e)) {}
};

// 函数调用：f(arg1, arg2, ...)（v0.5）
struct CallExpr : ASTNode {
    std::string func_name;
    std::vector<std::unique_ptr<ASTNode>> args;
    CallExpr(std::string f, std::vector<std::unique_ptr<ASTNode>> a)
        : func_name(std::move(f)), args(std::move(a)) {}
};

// ---- 语句 ----

// Block：花括号包着的多条语句 { ... }
struct Block : ASTNode {
    std::vector<std::unique_ptr<ASTNode>> stmts;
};

// return 语句：return expr; 或 return;（v0.5：expr 可为空表示 void return）
struct ReturnStmt : ASTNode {
    std::unique_ptr<ASTNode> expr;  // nullptr = void return
    explicit ReturnStmt(std::unique_ptr<ASTNode> e = nullptr)
        : expr(std::move(e)) {}
};

// 变量声明：int x = expr;
struct VarDecl : ASTNode {
    std::string name;
    std::unique_ptr<ASTNode> init;
    VarDecl(std::string n, std::unique_ptr<ASTNode> i)
        : name(std::move(n)), init(std::move(i)) {}
};

// 常量声明：const int x = expr;（v1.0）
struct ConstDecl : ASTNode {
    std::string name;
    std::unique_ptr<ASTNode> init;
    ConstDecl(std::string n, std::unique_ptr<ASTNode> i)
        : name(std::move(n)), init(std::move(i)) {}
};

// 赋值语句：x = expr;
struct AssignStmt : ASTNode {
    std::string name;
    std::unique_ptr<ASTNode> expr;
    AssignStmt(std::string n, std::unique_ptr<ASTNode> e)
        : name(std::move(n)), expr(std::move(e)) {}
};

// if 语句：if (cond) then [else else_stmt]（v0.3）
struct IfStmt : ASTNode {
    std::unique_ptr<ASTNode> cond;
    std::unique_ptr<ASTNode> then_stmt;
    std::unique_ptr<ASTNode> else_stmt;
    IfStmt(std::unique_ptr<ASTNode> c,
           std::unique_ptr<ASTNode> t,
           std::unique_ptr<ASTNode> e)
        : cond(std::move(c)), then_stmt(std::move(t)), else_stmt(std::move(e)) {}
};

// while 语句：while (cond) body（v0.4）
struct WhileStmt : ASTNode {
    std::unique_ptr<ASTNode> cond;
    std::unique_ptr<ASTNode> body;
    WhileStmt(std::unique_ptr<ASTNode> c, std::unique_ptr<ASTNode> b)
        : cond(std::move(c)), body(std::move(b)) {}
};

// break 语句（v0.4）
struct BreakStmt : ASTNode {};

// continue 语句（v0.4）
struct ContinueStmt : ASTNode {};

// ---- 顶层 ----

// 函数定义（v0.5：加入返回类型和参数列表）
struct FuncDef : ASTNode {
    std::string ret_type;           // "int" 或 "void"
    std::string name;
    std::vector<std::string> params; // 参数名列表
    std::unique_ptr<Block> body;
    FuncDef(std::string rt, std::string n,
            std::vector<std::string> ps, std::unique_ptr<Block> b)
        : ret_type(std::move(rt)), name(std::move(n)),
          params(std::move(ps)), body(std::move(b)) {}
};

// 程序根节点（v1.0：加入全局变量）
struct CompUnit : ASTNode {
    std::vector<std::unique_ptr<FuncDef>> funcs;
    std::vector<std::unique_ptr<ASTNode>> globals;  // 全局 VarDecl 或 ConstDecl
};

}  // namespace toyc
